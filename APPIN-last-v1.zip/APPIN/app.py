import os
import json
from datetime import datetime

import re

import joblib
import nltk
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from flask import (Flask, jsonify, redirect, render_template,
                   request, session, url_for)

nltk.download('punkt',     quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('stopwords', quiet=True)
nltk.download('wordnet',   quiet=True)
nltk.download('omw-1.4',   quiet=True)

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

# ─── Label normalisation (handles lowercase / numeric model outputs) ──────────
LABEL_MAP = {
    'positive': 'Positive', 'pos': 'Positive', '2': 'Positive',
    'negative': 'Negative', 'neg': 'Negative', '0': 'Negative',
    'neutral':  'Neutral',  'neu': 'Neutral',  '1': 'Neutral',
}

def normalize_label(label) -> str:
    s = str(label).strip()
    if s in ('Positive', 'Negative', 'Neutral'):
        return s
    return LABEL_MAP.get(s.lower(), s.capitalize())


# ─── Topic keywords for insight analysis ─────────────────────────────────────
TOPIC_KEYWORDS = {
    'Shipping & Delivery':    ['ship', 'deliver', 'package', 'courier', 'track', 'arriv', 'dispatch', 'transit', 'late'],
    'Login & Authentication': ['login', 'signin', 'sign in', 'password', 'auth', 'account', 'access', 'lock', 'credential'],
    'Payment & Billing':      ['pay', 'payment', 'charge', 'bill', 'refund', 'transaction', 'credit', 'card', 'invoice'],
    'Performance & Speed':    ['slow', 'lag', 'crash', 'freeze', 'hang', 'load', 'speed', 'unresponsive', 'stuck', 'performance'],
    'Customer Support':       ['support', 'customer service', 'help', 'response', 'staff', 'team', 'contact', 'ticket'],
    'UI & Design':            ['design', 'interface', 'confus', 'difficult', 'navigat', 'button', 'layout', 'screen'],
    'Features':               ['feature', 'function', 'option', 'update', 'useful', 'tool', 'capabilit', 'miss'],
    'Ease of Use':            ['easy', 'simple', 'intuitive', 'friend', 'convenient', 'smooth', 'straightforward'],
}

RECOMMENDATION_TEMPLATES = {
    'Shipping & Delivery':    'Improve shipping speed and delivery tracking to reduce negative reviews',
    'Login & Authentication': 'Enhance login stability and fix authentication issues for better user access',
    'Payment & Billing':      'Resolve payment processing issues and improve billing transparency',
    'Performance & Speed':    'Optimize app performance to reduce crashes and improve loading speed',
    'Customer Support':       'Strengthen customer support responsiveness and issue-resolution time',
    'UI & Design':            'Improve UI/UX design for better navigation and usability',
    'Features':               'Prioritise missing features requested by users to increase satisfaction',
    'Ease of Use':            'Simplify user flows and onboarding to make the app more intuitive',
}


def analyze_topics(reviews: list) -> dict:
    """Count how many reviews mention each topic. Returns {topic: {count, pct}}."""
    total = len(reviews)
    if not total:
        return {}
    counts = {t: 0 for t in TOPIC_KEYWORDS}
    for text in reviews:
        lower = text.lower()
        for topic, keywords in TOPIC_KEYWORDS.items():
            if any(kw in lower for kw in keywords):
                counts[topic] += 1
    result = {
        t: {'count': c, 'pct': round(c / total * 100, 1)}
        for t, c in counts.items() if c > 0
    }
    return dict(sorted(result.items(), key=lambda x: x[1]['count'], reverse=True))


def generate_recommendations(neg_insights: dict, neg_pct: float) -> list:
    """Return a list of recommendation dicts based on negative-topic analysis."""
    recs = []
    for topic, info in list(neg_insights.items())[:4]:
        pct = info['pct']
        if pct < 10:
            continue
        priority = 'high' if pct >= 30 else 'medium' if pct >= 15 else 'low'
        recs.append({
            'topic':    topic,
            'pct':      pct,
            'text':     RECOMMENDATION_TEMPLATES.get(topic, f'Address {topic} issues'),
            'priority': priority,
        })
    if neg_pct >= 30 and not any(r['topic'] == 'General' for r in recs):
        recs.append({
            'topic':    'General',
            'pct':      neg_pct,
            'text':     'Overall negative sentiment is high — conduct a comprehensive app review and user-feedback session.',
            'priority': 'high',
        })
    return recs


def preprocess(text: str) -> str:
    text   = re.sub(r"http\S+", "", str(text))
    text   = re.sub(r"[^a-zA-Z\s]", "", text).lower()
    tokens = word_tokenize(text)
    tokens = [lemmatizer.lemmatize(w) for w in tokens if w not in stop_words]
    return " ".join(tokens)


app = Flask(__name__)
app.secret_key = 'appinsight-secret-key-2026'

# ─── Load ML model & vectorizer ──────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model      = joblib.load(os.path.join(BASE_DIR, 'sentiment_model.pkl'))
vectorizer = joblib.load(os.path.join(BASE_DIR, 'tfidf_vectorizer.pkl'))

# ─── User storage (JSON file) ────────────────────────────────────────────────
USERS_FILE = os.path.join(BASE_DIR, 'users.json')

ADMIN_EMAIL    = 'admin@appinsight.io'
ADMIN_PASSWORD = 'Admin@123'


def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return []


def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)


# ─── Sentiment helpers ────────────────────────────────────────────────────────

def predict_texts(texts):
    """
    Predict sentiment for a list of texts using the trained TF-IDF + LinearSVC model.

    Pipeline (must match training-time preprocessing exactly):
      1. Clean text  – remove URLs, non-alphabetic chars, lowercase
      2. Tokenise    – word_tokenize
      3. Filter      – remove NLTK English stopwords (same list used at training)
      4. Lemmatise   – WordNetLemmatizer (default noun POS, same as training)
      5. Vectorise   – TF-IDF transform with the saved vectorizer
      6. Predict     – LinearSVC.predict  →  'Positive' | 'Negative' | 'Neutral'
      7. Confidence  – softmax over decision_function scores

    Returns: (labels, confidences)  – parallel lists, same length as `texts`.
    """
    cleaned = [preprocess(t) for t in texts]
    X       = vectorizer.transform(cleaned)

    # Raw model labels are already title-cased ('Positive', 'Negative', 'Neutral')
    # normalize_label handles any unexpected formats from future model versions
    labels = [normalize_label(l) for l in model.predict(X).tolist()]

    print("Predictions types:", set(labels))

    # Confidence via softmax on decision-function distances
    try:
        scores = model.decision_function(X)          # (n_samples, n_classes)
        if scores.ndim == 1:                          # binary fallback (shouldn't happen)
            scores = scores.reshape(-1, 1)
        exp_s  = np.exp(scores - scores.max(axis=1, keepdims=True))
        proba  = exp_s / exp_s.sum(axis=1, keepdims=True)
        confs  = proba.max(axis=1).tolist()
    except Exception:
        confs = [None] * len(labels)

    return labels, confs


def expected_sentiment(rating):
    """Map a star rating to its expected sentiment."""
    try:
        r = float(rating)
    except (ValueError, TypeError):
        return None
    if r <= 2:  return 'Negative'
    if r == 3:  return 'Neutral'
    return 'Positive'


def analyze_dataframe(df):
    """Run the model over a DataFrame that has a 'review' column."""
    texts = df['review'].fillna('').astype(str).tolist()
    labels, confs = predict_texts(texts)

    results = []
    for idx, (row_idx, row) in enumerate(df.iterrows()):
        rating    = str(row.get('rating', ''))
        predicted = labels[idx]
        expected  = expected_sentiment(rating)

        
        final_sentiment = expected if expected else predicted

        try:
            r = float(rating)
        except (ValueError, TypeError):
            r = None
        mismatch = (
            r is not None and (
                (1 <= r <= 2 and predicted == 'Positive') or
                (4 <= r <= 5 and predicted == 'Negative')
            )
        )

        results.append({
            'review_text': str(row.get('review', '')),
            'rating':      rating,
            'app_name':    str(row.get('app_name', '')),
            'sentiment':   final_sentiment,  
            'confidence':  round(confs[idx] * 100, 1) if confs[idx] is not None else None,
            'expected':    expected or '—',
            'mismatch':    mismatch,
        })

    total = len(results)
    counts = {}
    for r in results:
        counts[r['sentiment']] = counts.get(r['sentiment'], 0) + 1

    summary = {}
    for label, count in counts.items():
        summary[label] = {
            'count': count,
            'pct':   round(count / total * 100, 1) if total else 0,
        }
    for label in ('Positive', 'Negative', 'Neutral'):
        summary.setdefault(label, {'count': 0, 'pct': 0.0})

    mismatch_count = sum(1 for r in results if r['mismatch'])
    mismatch_pct   = round(mismatch_count / total * 100, 1) if total else 0

    # ── Topic insights ───────────────────────────────────────────────────────
    neg_texts = [r['review_text'] for r in results if r['sentiment'] == 'Negative']
    pos_texts = [r['review_text'] for r in results if r['sentiment'] == 'Positive']
    neg_insights = analyze_topics(neg_texts)
    pos_insights = analyze_topics(pos_texts)
    neg_pct_val  = summary.get('Negative', {}).get('pct', 0)
    recommendations = generate_recommendations(neg_insights, neg_pct_val)

    return {
        'total':           total,
        'summary':         summary,
        'results':         results,
        'mismatch_count':  mismatch_count,
        'mismatch_pct':    mismatch_pct,
        'neg_insights':    neg_insights,
        'pos_insights':    pos_insights,
        'recommendations': recommendations,
    }

# ═══════════════════════════════════════════════════════════════════════════════
# PAGE ROUTES  (serve every HTML template at its original filename)
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/')
@app.route('/HomePage.html')
def home():
    return render_template('HomePage.html')


@app.route('/login.html')
@app.route('/login')
def login_page():
    return render_template('login.html')


@app.route('/login-admin.html')
@app.route('/admin-login')
def admin_login_page():
    return render_template('login-admin.html')


@app.route('/signup.html')
@app.route('/signup')
def signup_page():
    return render_template('signup.html')


@app.route('/forget_password.html')
def forget_password():
    return render_template('forget_password.html')


@app.route('/FAQ.html')
@app.route('/faq')
def faq():
    return render_template('FAQ.html')


@app.route('/logout.html')
@app.route('/logout')
def logout():
    session.clear()
    return render_template('logout.html')


@app.route('/profile.html')
def profile():
    return render_template('profile.html')


# ── User dashboard pages ──────────────────────────────────────────────────────

@app.route('/user-dashboard.html')
@app.route('/dashboard')
def user_dashboard():
    return render_template('user-dashboard.html')


@app.route('/uploadFile.html')
@app.route('/upload')
def upload_page():
    return render_template('uploadFile.html')


@app.route('/uploadedfile.html')
@app.route('/files')
def file_library():
    return render_template('uploadedfile.html')


@app.route('/Compare_apps.html')
@app.route('/compare')
def compare_page():
    return render_template('Compare_apps.html')


# ── Admin pages ───────────────────────────────────────────────────────────────

@app.route('/admin-dashboard.html')
@app.route('/admin')
def admin_dashboard():
    return render_template('admin-dashboard.html')


@app.route('/AdminManageUsers.html')
@app.route('/admin/users')
def admin_manage_users():
    return render_template('AdminManageUsers.html')


@app.route('/admin-model.html')
@app.route('/admin/model')
def admin_model_page():
    return render_template('admin-model.html')


@app.route('/admin-faq.html')
@app.route('/admin/faq')
def admin_faq():
    return render_template('admin-faq.html')


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/signup', methods=['POST'])
def api_signup():
    data     = request.get_json()
    name     = data.get('name', '').strip()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not name or not email or not password:
        return jsonify({'success': False, 'error': 'All fields are required.'}), 400

    users = load_users()
    if any(u['email'] == email for u in users):
        return jsonify({'success': False, 'error': 'Email already registered.'}), 409

    users.append({
        'id':         len(users) + 1,
        'name':       name,
        'email':      email,
        'password':   password,          # hash in production
        'status':     'active',
        'created_at': datetime.now().isoformat(),
    })
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/login', methods=['POST'])
def api_login():
    data     = request.get_json()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    users = load_users()
    user  = next((u for u in users
                  if u['email'] == email and u['password'] == password), None)

    if not user:
        return jsonify({'success': False, 'error': 'Invalid email or password.'}), 401

    session['user_id']    = user['id']
    session['user_email'] = user['email']
    session['user_name']  = user['name']
    return jsonify({'success': True, 'user': {'name': user['name'], 'email': user['email']}})


@app.route('/api/admin/login', methods=['POST'])
def api_admin_login():
    data     = request.get_json()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
        session['admin'] = True
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid admin credentials.'}), 401


@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True})


# ═══════════════════════════════════════════════════════════════════════════════
# SENTIMENT MODEL API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """
    POST a CSV file (multipart/form-data, field name 'file').
    Returns full sentiment analysis results as JSON.
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded.'}), 400

    file = request.files['file']
    if not file.filename.lower().endswith('.csv'):
        return jsonify({'error': 'Only CSV files are supported.'}), 400

    try:
        df = pd.read_csv(file)
        df.columns = df.columns.str.strip().str.lower()

        if 'review' not in df.columns:
            return jsonify({'error': 'CSV must contain a "review" column.'}), 422

        result = analyze_dataframe(df)
        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict', methods=['POST'])
def api_predict():
    """
    POST JSON {"text": "..."}.
    Returns {"sentiment": "Positive"|"Negative"|"Neutral", "confidence": 87.3}.
    """
    data = request.get_json()
    text = data.get('text', '').strip() if data else ''

    if not text:
        return jsonify({'error': 'No text provided.'}), 400

    try:
        labels, confs = predict_texts([text])
        return jsonify({
            'sentiment':  labels[0],
            'confidence': round(confs[0] * 100, 1) if confs[0] is not None else None,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/mismatch', methods=['POST'])
def api_mismatch():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded.'}), 400
    file = request.files['file']
    if not file.filename.lower().endswith('.csv'):
        return jsonify({'error': 'Only CSV files are supported.'}), 400
    try:
        df = pd.read_csv(file)
        df.columns = df.columns.str.strip().str.lower()
        if 'review' not in df.columns:
            return jsonify({'error': 'CSV must contain a "review" column.'}), 422

        texts          = df['review'].fillna('').astype(str).tolist()
        labels, _      = predict_texts(texts)

        total          = len(labels)
        mismatch_count = 0
        chart_data     = {str(s): {'Positive': 0, 'Neutral': 0, 'Negative': 0} for s in range(1, 6)}

        for idx, (_, row) in enumerate(df.iterrows()):
            predicted = labels[idx]
            try:
                star = min(max(round(float(row.get('rating', 0))), 1), 5)
            except (ValueError, TypeError):
                star = 0

            if star > 0:
                chart_data[str(star)][predicted] = chart_data[str(star)].get(predicted, 0) + 1

            if (1 <= star <= 2 and predicted == 'Positive') or \
               (4 <= star <= 5 and predicted == 'Negative'):
                mismatch_count += 1

        mismatch_pct = round(mismatch_count / total * 100, 1) if total else 0
        return jsonify({
            'total':          total,
            'mismatch_count': mismatch_count,
            'mismatch_pct':   mismatch_pct,
            'chart_data':     chart_data,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/compare', methods=['POST'])
def api_compare():
    """
    POST two CSV files (multipart/form-data, fields 'file1' and 'file2').
    Returns {"app1": {...}, "app2": {...}} with full analysis for each.
    """
    f1 = request.files.get('file1')
    f2 = request.files.get('file2')

    if not f1 or not f2:
        return jsonify({'error': 'Two CSV files are required (file1 and file2).'}), 400

    try:
        df1 = pd.read_csv(f1)
        df2 = pd.read_csv(f2)
        df1.columns = df1.columns.str.strip().str.lower()
        df2.columns = df2.columns.str.strip().str.lower()

        if 'review' not in df1.columns or 'review' not in df2.columns:
            return jsonify({'error': 'Both CSVs must contain a "review" column.'}), 422

        def cap_results(data, n=20):
            data['results'] = data['results'][:n]
            return data

        return jsonify({'app1': cap_results(analyze_dataframe(df1)), 'app2': cap_results(analyze_dataframe(df2))})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/admin/users', methods=['GET'])
def api_admin_users():
    users = load_users()
    safe  = [
        {
            'id':         u['id'],
            'name':       u['name'],
            'email':      u['email'],
            'status':     u.get('status', 'active'),
            'created_at': u.get('created_at', ''),
        }
        for u in users
    ]
    return jsonify(safe)


@app.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
def api_admin_delete_user(user_id):
    users = [u for u in load_users() if u['id'] != user_id]
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/admin/users/<int:user_id>/status', methods=['PATCH'])
def api_admin_update_status(user_id):
    data   = request.get_json()
    status = data.get('status')
    users  = load_users()
    for u in users:
        if u['id'] == user_id:
            u['status'] = status
            break
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/admin/model/stats', methods=['GET'])
def api_admin_model_stats():
    return jsonify({
        'accuracy':         '87%',
        'f1_score':         0.86,
        'precision':        0.88,
        'version':          'v2.1',
        'algorithm':        'TF-IDF + Logistic Regression',
        'training_samples': 12450,
        'last_trained':     'Jan 15, 2026',
    })


# ─── Run ──────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    app.run(debug=True)
