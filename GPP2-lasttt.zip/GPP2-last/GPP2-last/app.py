from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
import re
from collections import Counter

app = Flask(__name__)

# ───────────── تحميل المودل ─────────────
model = joblib.load("sentiment_model_v2.pkl")
vectorizer = joblib.load("tfidf_vectorizer_v2.pkl")

# حفظ آخر نتيجة
last_result = {
    "positive": 0,
    "negative": 0,
    "neutral": 0,
    "total": 0,
    "keywords": [],
    "samples": [],
    "avg_rating": 0,
    "rating_counts": {}
}


# ───────────── تنظيف النص ─────────────
def clean_text(text):
    text = re.sub(r"http\S+", "", str(text))
    text = re.sub(r"[^a-zA-Z\s]", "", text)
    text = text.lower()
    return text


# ───────────── الصفحات ─────────────

@app.route("/")
def home():
    return render_template("HomePage.html")


@app.route("/compare-page")
def compare_page():
    return render_template("compare_apps.html")


@app.route("/upload")
def upload():
    return render_template("uploadFile.html")


@app.route("/dashboard")
def dashboard():
    return render_template("user-dashboard.html")


@app.route("/uploaded-files")
def uploaded_files():
    return render_template("uploadedfile.html")


@app.route("/login")
def login():
    return render_template("login.html")


@app.route("/faq")
def faq():
    return render_template("FAQ.html")


@app.route("/signup")
def signup():
    return render_template("signup.html")


@app.route("/forget-password")
def forget_password():
    return render_template("forget_password.html")


@app.route("/logout")
def logout():
    return render_template("logout.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


# ───────────── صفحات الأدمن ─────────────

@app.route("/admin-dashboard")
def admin_dashboard():
    return render_template("admin-dashboard.html")


@app.route("/manage-users")
def manage_users():
    return render_template("AdminManageUsers.html")


@app.route("/admin-model")
def admin_model():
    return render_template("admin-model.html")


@app.route("/admin-faq")
def admin_faq():
    return render_template("admin-faq.html")


@app.route("/admin-login")
def admin_login():
    return render_template("login-admin.html")


# ───────────── تحليل البيانات ─────────────
def process_dataframe(df):

    # تحديد عمود الريفيو
    if "review" in df.columns:
        raw_text = df["review"]
    elif "review_text" in df.columns:
        raw_text = df["review_text"]
    else:
        raw_text = df.iloc[:, 0]

    raw_text = raw_text.astype(str)

    # تنظيف
    clean = raw_text.apply(clean_text)

    # مودل
    vec = vectorizer.transform(clean)
    predictions = model.predict(vec)

    # حساب
    positive = (predictions == "Positive").sum()
    negative = (predictions == "Negative").sum()
    neutral  = (predictions == "Neutral").sum()

    # ⭐🔥 Sample Reviews مع التصنيف
    sample_reviews = []
    for i in range(min(5, len(raw_text))):
        sample_reviews.append({
            "text": raw_text.iloc[i],
            "sentiment": predictions[i]
        })

    # ☁️ Keywords
    words = " ".join(clean).split()
    common_words = [w for w, _ in Counter(words).most_common(10)]

    # ⭐ Rating
    if "rating" in df.columns:
        avg_rating = round(df["rating"].mean(), 1)
        rating_counts = df["rating"].value_counts().sort_index().to_dict()
    else:
        avg_rating = 0
        rating_counts = {}

    return {
        "positive": int(positive),
        "negative": int(negative),
        "neutral": int(neutral),
        "total": len(predictions),
        "keywords": common_words,
        "samples": sample_reviews,  # 🔥 مهم
        "avg_rating": avg_rating,
        "rating_counts": rating_counts
    }
# ───────────── Compare ─────────────

@app.route("/compare", methods=["POST"])
def compare():
    file1 = request.files.get("file1")
    file2 = request.files.get("file2")

    if not file1 or not file2:
        return jsonify({"error": "Upload two files"}), 400

    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)

    result1 = process_dataframe(df1)
    result2 = process_dataframe(df2)

    return jsonify({
        "app1": result1,
        "app2": result2
    })


# ───────────── Upload + Dashboard ─────────────

@app.route("/analyze-file", methods=["POST"])
def analyze_file():
    global last_result

    file = request.files.get("file")

    # لو بدون ملف (dashboard)
    if not file:
        return jsonify(last_result)

    try:
        df = pd.read_csv(file)

        result = process_dataframe(df)

        last_result = result
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ───────────── تشغيل السيرفر ─────────────
if __name__ == "__main__":
    app.run(debug=True)