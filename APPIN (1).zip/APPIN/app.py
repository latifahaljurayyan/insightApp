import os
import json
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from flask import (Flask, jsonify, redirect, render_template,
                   request, session, url_for)

app = Flask(__name__)
app.secret_key = 'appinsight-secret-key-2026'

# ─── Load ML model & vectorizer ──────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model      = joblib.load(os.path.join(BASE_DIR, 'sentiment_model.pkl'))
vectorizer = joblib.load(os.path.join(BASE_DIR, 'tfidf_vectorizer.pkl'))

# ─── User storage (JSON file) ────────────────────────────────────────────────
USERS_FILE = os.path.join(BASE_DIR, 'users.json')

ADMIN_EMAIL    = 'admin@appinsight.io'
ADMIN_PASSWORD = 'Admin@123'


def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return []


def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)


# ─── Sentiment helpers ────────────────────────────────────────────────────────

def predict_texts(texts):
    """Return (labels, confidences) for a list of strings."""
    X      = vectorizer.transform(texts)
    labels = model.predict(X).tolist()
    try:
        # LinearSVC uses decision_function; softmax converts scores to pseudo-proba
        scores = model.decision_function(X)
        if scores.ndim == 1:
            scores = scores.reshape(-1, 1)
        exp    = np.exp(scores - scores.max(axis=1, keepdims=True))
        proba  = exp / exp.sum(axis=1, keepdims=True)
        confs  = proba.max(axis=1).tolist()
    except Exception:
        try:
            proba = model.predict_proba(X)
            confs = proba.max(axis=1).tolist()
        except Exception:
            confs = [None] * len(labels)
    return labels, confs


def analyze_dataframe(df):
    """Run the model over a DataFrame that has a 'review' column."""
    texts = df['review'].fillna('').astype(str).tolist()
    labels, confs = predict_texts(texts)

    results = []
    for idx, (row_idx, row) in enumerate(df.iterrows()):
        results.append({
            'review_text': str(row.get('review', '')),
            'rating':      str(row.get('rating', '')),
            'app_name':    str(row.get('app_name', '')),
            'sentiment':   labels[idx],
            'confidence':  round(confs[idx] * 100, 1) if confs[idx] is not None else None,
        })

    total = len(results)
    counts = {}
    for r in results:
        counts[r['sentiment']] = counts.get(r['sentiment'], 0) + 1

    summary = {}
    for label, count in counts.items():
        summary[label] = {
            'count': count,
            'pct':   round(count / total * 100, 1) if total else 0,
        }
    for label in ('Positive', 'Negative', 'Neutral'):
        summary.setdefault(label, {'count': 0, 'pct': 0.0})

    return {'total': total, 'summary': summary, 'results': results}


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE ROUTES  (serve every HTML template at its original filename)
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/')
@app.route('/HomePage.html')
def home():
    return render_template('HomePage.html')


@app.route('/login.html')
@app.route('/login')
def login_page():
    return render_template('login.html')


@app.route('/login-admin.html')
@app.route('/admin-login')
def admin_login_page():
    return render_template('login-admin.html')


@app.route('/signup.html')
@app.route('/signup')
def signup_page():
    return render_template('signup.html')


@app.route('/forget_password.html')
def forget_password():
    return render_template('forget_password.html')


@app.route('/FAQ.html')
@app.route('/faq')
def faq():
    return render_template('FAQ.html')


@app.route('/logout.html')
@app.route('/logout')
def logout():
    session.clear()
    return render_template('logout.html')


@app.route('/profile.html')
def profile():
    return render_template('profile.html')


# ── User dashboard pages ──────────────────────────────────────────────────────

@app.route('/user-dashboard.html')
@app.route('/dashboard')
def user_dashboard():
    return render_template('user-dashboard.html')


@app.route('/uploadFile.html')
@app.route('/upload')
def upload_page():
    return render_template('uploadFile.html')


@app.route('/uploadedfile.html')
@app.route('/files')
def file_library():
    return render_template('uploadedfile.html')


@app.route('/Compare_apps.html')
@app.route('/compare')
def compare_page():
    return render_template('Compare_apps.html')


# ── Admin pages ───────────────────────────────────────────────────────────────

@app.route('/admin-dashboard.html')
@app.route('/admin')
def admin_dashboard():
    return render_template('admin-dashboard.html')


@app.route('/AdminManageUsers.html')
@app.route('/admin/users')
def admin_manage_users():
    return render_template('AdminManageUsers.html')


@app.route('/admin-model.html')
@app.route('/admin/model')
def admin_model_page():
    return render_template('admin-model.html')


@app.route('/admin-faq.html')
@app.route('/admin/faq')
def admin_faq():
    return render_template('admin-faq.html')


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/signup', methods=['POST'])
def api_signup():
    data     = request.get_json()
    name     = data.get('name', '').strip()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not name or not email or not password:
        return jsonify({'success': False, 'error': 'All fields are required.'}), 400

    users = load_users()
    if any(u['email'] == email for u in users):
        return jsonify({'success': False, 'error': 'Email already registered.'}), 409

    users.append({
        'id':         len(users) + 1,
        'name':       name,
        'email':      email,
        'password':   password,          # hash in production
        'status':     'active',
        'created_at': datetime.now().isoformat(),
    })
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/login', methods=['POST'])
def api_login():
    data     = request.get_json()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    users = load_users()
    user  = next((u for u in users
                  if u['email'] == email and u['password'] == password), None)

    if not user:
        return jsonify({'success': False, 'error': 'Invalid email or password.'}), 401

    session['user_id']    = user['id']
    session['user_email'] = user['email']
    session['user_name']  = user['name']
    return jsonify({'success': True, 'user': {'name': user['name'], 'email': user['email']}})


@app.route('/api/admin/login', methods=['POST'])
def api_admin_login():
    data     = request.get_json()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
        session['admin'] = True
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid admin credentials.'}), 401


@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True})


# ═══════════════════════════════════════════════════════════════════════════════
# SENTIMENT MODEL API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """
    POST a CSV file (multipart/form-data, field name 'file').
    Returns full sentiment analysis results as JSON.
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded.'}), 400

    file = request.files['file']
    if not file.filename.lower().endswith('.csv'):
        return jsonify({'error': 'Only CSV files are supported.'}), 400

    try:
        df = pd.read_csv(file)
        df.columns = df.columns.str.strip().str.lower()

        if 'review' not in df.columns:
            return jsonify({'error': 'CSV must contain a "review" column.'}), 422

        result = analyze_dataframe(df)
        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict', methods=['POST'])
def api_predict():
    """
    POST JSON {"text": "..."}.
    Returns {"sentiment": "Positive"|"Negative"|"Neutral", "confidence": 87.3}.
    """
    data = request.get_json()
    text = data.get('text', '').strip() if data else ''

    if not text:
        return jsonify({'error': 'No text provided.'}), 400

    try:
        labels, confs = predict_texts([text])
        return jsonify({
            'sentiment':  labels[0],
            'confidence': round(confs[0] * 100, 1) if confs[0] is not None else None,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/compare', methods=['POST'])
def api_compare():
    """
    POST two CSV files (multipart/form-data, fields 'file1' and 'file2').
    Returns {"app1": {...}, "app2": {...}} with full analysis for each.
    """
    f1 = request.files.get('file1')
    f2 = request.files.get('file2')

    if not f1 or not f2:
        return jsonify({'error': 'Two CSV files are required (file1 and file2).'}), 400

    try:
        df1 = pd.read_csv(f1)
        df2 = pd.read_csv(f2)
        df1.columns = df1.columns.str.strip().str.lower()
        df2.columns = df2.columns.str.strip().str.lower()

        if 'review' not in df1.columns or 'review' not in df2.columns:
            return jsonify({'error': 'Both CSVs must contain a "review" column.'}), 422

        return jsonify({'app1': analyze_dataframe(df1), 'app2': analyze_dataframe(df2)})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN API
# ═══════════════════════════════════════════════════════════════════════════════

@app.route('/api/admin/users', methods=['GET'])
def api_admin_users():
    users = load_users()
    safe  = [
        {
            'id':         u['id'],
            'name':       u['name'],
            'email':      u['email'],
            'status':     u.get('status', 'active'),
            'created_at': u.get('created_at', ''),
        }
        for u in users
    ]
    return jsonify(safe)


@app.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
def api_admin_delete_user(user_id):
    users = [u for u in load_users() if u['id'] != user_id]
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/admin/users/<int:user_id>/status', methods=['PATCH'])
def api_admin_update_status(user_id):
    data   = request.get_json()
    status = data.get('status')
    users  = load_users()
    for u in users:
        if u['id'] == user_id:
            u['status'] = status
            break
    save_users(users)
    return jsonify({'success': True})


@app.route('/api/admin/model/stats', methods=['GET'])
def api_admin_model_stats():
    return jsonify({
        'accuracy':         '87%',
        'f1_score':         0.86,
        'precision':        0.88,
        'version':          'v2.1',
        'algorithm':        'TF-IDF + Logistic Regression',
        'training_samples': 12450,
        'last_trained':     'Jan 15, 2026',
    })


# ─── Run ──────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    app.run(debug=True)
