from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__, template_folder=".")

model = joblib.load("tfidf_model.joblib")
vectorizer = joblib.load("tfidf_vectorizer.joblib")


def analyze(file):

    df = pd.read_csv(file)

    text = df.iloc[:,0]

    vec = vectorizer.transform(text)

    predictions = model.predict(vec)

    positive = (predictions == "Positive").sum()
    negative = (predictions == "Negative").sum()

    return positive, negative


@app.route("/")
def home():
    return render_template("Compare_apps.html")


@app.route("/compare", methods=["POST"])
def compare():

    file1 = request.files["file1"]
    file2 = request.files["file2"]

    pos1, neg1 = analyze(file1)
    pos2, neg2 = analyze(file2)

    return {
        "App1 Positive": int(pos1),
        "App1 Negative": int(neg1),
        "App2 Positive": int(pos2),
        "App2 Negative": int(neg2)
}

@app.route("/profile")
def profile():
    return render_template("profile.html")

@app.route("/upload")
def upload():
    return render_template("uploadedfile.html")
if __name__ == "__main__":
    app.run(debug=True) 